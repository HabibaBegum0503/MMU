How to use the system:

click "Carbon Calculator" tab
	Click any tab ("Transportation, Flights ... Water") within the side panel of this tab and change the choices for each question for the output graph to change values.
	Within the main panel of the tab there is a choice of graph:
		Footprint of each section - shows the footprint equivalent for each tab within the side panel.
		Comparison to average - calculates the overall carbon footprint and shows it against the average carbon footprint of the UK.

click "Ways To Reduce" tab
	This tab just shows some ways to reduce and has links to helpful tabs
	Gives credit to the sources that were used to create the Carbon Calculator.
